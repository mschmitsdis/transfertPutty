rawOut.php

To use this NagVis gadget, place the rawOut.php file and the rawOut/
subdirectory in your gadgets directory, /usr/local/nagvis/share/usersfiles/gadgets 
by default.  You can pass the gadget multiple options by separating them 
with a comma ','.

USAGE:

	By default it will display perfdata from a service check, it can also
	display service states i.e. ok, warning, etc.  There are numerous options 
	available some apply only when displaying perfdata others only when 
	displaying service states. 

OPTIONS:

These are general options that apply regardless of what is displayed.

	bgcolor - Background Color
		The gadget assumes a white background by default, however if
		you are using other background colors on your maps set this 
		option to the same color as the background to smooth out 
		the edges of the display.  Colors are given as hex values.

	EXAMPLE:
		bgcolor=#000000

	font
		The gadget uses true type fonts, it expects them in a subdirectory 
		of the gadgets directory called 'rawOut/'.  You can 
		change the font used to display your data by adding it to this 
		subdirectory and passing the font option to the gadget.  
		There are a couple of fonts included already, the default is arial.

	EXAMPLE:
		font=comic.ttf

The next few options are applied only when displaying perfdata.

	uom - unit of measure
		The gadget will use the uom value from the perfdata if it exists.
		You can override it or add your own with this option.

	EXAMPLE:
		uom=%

	pdi - perfdata index
		This option tells the gadget which perfdata to display.
		Nagios service checks can return multiple sets of perfdata, 
		to display perfdata beyond the first one use this option.

	EXAMPLE:
	
		pdi=2 will display the second perfdata value from a service
		check

	scaleunits
		Sometimes the raw numbers returned from a check are very
		large.  When the service check reports Bytes or bits for 
		example the number can be quite big.  This options tells the 
		gadget to convert the perfdata to a larger unit so that the 
		number displayed is not so big.  For example if the perfdata 
		your displaying is 483354994 with this option enabled the gadget 
		will display that as 483.35M.  Or if your perfdata is '483354994 Bytes' 
		it will interpret the uom and display 461.05MB.  It can also convert 
		time in seconds, for example perfdata of 1567152s can be 
		displayed as 18d:3h:19m:12s.  This option will also recongnize
		a uom that you've passed as an option to the gadget.

	EXAMPLE:
		scaleunits=yes

	percent - percentage of total
		With this flag set and Min and Max values included in the plug-in
		the gadget will output the current check value as a percentage
		of the Max value.  Thanks to Christian Weisheit.

	EXAMPLE:
		percent=yes


These next options are used only when you want the gadget to display the state of
the service not it's perfdata.  If your service check does not have perfdata you will 
also need the 'no_perf' option to prevent a perfdata error from the gadget engine.

	showstate
		This option tells the gadget to ignore the perfdata and
		display the state (ok, warning, critical, or unknown) of 
		the service as text.  By default it will display the literal 
		state, i.e. 'ok', or 'warning', etc.  You can customize the 
		values it displays with the next option.

	EXAMPLE:
		showstate=yes

	ok|warning|critical|unknown
		This option tells the gadget to change what text it displays
		for the current state of the service.  You only have to provide 
		the ones you want changed, the others will display the default text.  

	EXAMPLE:
		ok=Running,critical=Stopped

Complete examples:

	The following output is sample perfdata provided from a
	check_ifTraffic3.pl

		inUsage=0.01%;50;98 outUsage=0.07%;50;98 inBandwidth=105.68Kbs
		outBandwidth=1.26Mbs inAbsolut=2542311262 outAbsolut=92324244

	To display the last value '92324244' as scaled bits use the following
	options:

		pdi=6,uom=bits,scaleunits=yes

	Note: In this example the gadget would display: 88.05Mbits

	To display the state of a server room humidifier as 'humidifying' when
	the service check is okay and 'off' when it's set to critical, use the 
	following options:

		ok=humidifying,critical=off

	Note: showstate is assumed if your specifying any of the state
	options.


