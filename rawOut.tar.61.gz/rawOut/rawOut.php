<?php
/*****************************************************************************
 *
 * This code is based on the rawNumbers.php script
 * 
 * rawNumbers.php
 * Copyright (c) 2008-2009 by Sascha Runschke (Contact: Sascha.Runschke@gfkl.com)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * rawOut - Display perfdata or service state text from Nagios service checks 
 * in the NagVis addon.
 * by Greg Frater, greg AT fraterfactory DOT com
 *
 * This gadget displays the raw numbers of performance data or the state (i.e. ok, 
 * warning, critical, etc) of the object from nagios.
 * It started as rawNumbers by Sascha Runschke to help display temperature 
 * and humidity on large displays, but it has expanded to include text based
 * on the state of a service in Nagios too.
 *
 * The displayed string is rendered as png image with ttf script, while
 * the color of the numbers or text reflect the state of the service:
 * Green for OK, yellow for WARNING, red for CRITICAL.
 * BUT: this gadget only honors HARD states and considers any SOFT state
 * as OK, no matter if it's WARNING or CRITICAL.
 *
 * There are several options that can be passed to the gadget to modify it's 
 * behavior.  The options and how they are used are listed below.  The gadget 
 * 
 * Gadget options are available as of NagVis 1.4.3.  Options are passed as a 
 * key = value pair.  You can pass the gadget more than one option by separating 
 * them with a comma ','.
 * 

/***************************** USAGE ************************************************

USAGE:

	Default usage is to display perfdata from a service check.  There are 
	numerous options available, some apply only when displaying perfdata 
	others only when displaying service states. 
	
	For a detailed description of options check out the readme file that came with the 
	gadget, rawOut.readme.  This is just a quick reference for gadget options.

	Note: If your service check does not have perdata you will need the 'no_perf' option
	to prevent a missing perfdata error from the gadget engine.

OPTIONS:

	bgcolor - color specified in hex (bgcolor=#000000)
	font - file name of True Type font in rawOut/ subdirectory (font=comic.ttf)
	uom - unit of measure to display (uom=%) 
	pdi - performace data to display (pdi=2)
	scaleunits - Binary flag to enable unit scaling (scaleunits=yes)
	showstate - Binary flag to enable output of state info instead of perfdata (showstate=yes)
	ok|warning|critical|unknown - Custom text to display for various states (ok=running,critical=stopped)
	percent - Binary flag to enable output as percent (percent=yes), requires min and max values

More Examples:

	The following output is sample perfdata provided from a service check called 
	check_ifTraffic3.pl

		inUsage=0.01%;50;98 outUsage=0.07%;50;98 inBandwidth=105.68Kbs 
		outBandwidth=1.26Mbs inAbsolut=2542311262 outAbsolut=92324244

	To display the last value '92324244' as scaled bits use the following options:

		pdi=6,uom=bits,scaleunits=yes

	Note: IN this example the gadget would display: 88.05Mbits

	To display the state of a server room humidifier as 'humidifying' when the 
	service check is okay and 'off' when it's set to critical, use the following 
	options:

		ok=humidifying,critical=off

	Note: showstate is assumed if your specifying any of the state options.

*******************************************************************************************/


// Set dummy perfdata for displaying the gadget in nagvis WUI mode
$sDummyPerfdata = "Temperature=99.5C;99,6;99,9;15;100 Humidity=50%;60;85;0;100 Temperature=99.5C;99,6;99,9;15;100 Humidity=50%;60;85;0;100 Humidity=50%;60;85;0;100 Humidity=50%;60;85;0;100 Humidity=50%;60;85;0;100";

// Set default state values
$stateArray = array("OK" => "OK", "WARNING" => "WARNING", "CRITICAL" => "CRITICAL", "UNKNOWN" => "UNKNOWN");

require('./gadgets_core.php');

$fontFile = './rawOut/arial.ttf';
#$fontFile = './rawOut/luxirr.ttf';
#$fontFile = './rawOut/comic.ttf';
#$fontFile = './rawOut/arcane_regular.ttf';

/*******************************************************************************
 * Sanity checking - we need a ttf font and the freetype2 library installed!
 * ****************************************************************************/ 

// If it does not exist - bail out!
if ( ! file_exists($fontFile) ) {
        errorBox("ERROR: FontFile $fontFile not found");
}

if ( ! function_exists('imagettfbbox') ) {
        errorBox('The FreeType2 library is needed by this gadget!');
}

/*******************************************************************************
 * Assign initial/default valutes 
 * ****************************************************************************/ 

$value = $aPerfdata[0]['value'];
$min = $aPerfdata[0]['min'];
$max = $aPerfdata[0]['max'];
$uom = $aPerfdata[0]['uom'];
$state = $aOpts['state'];
$stateType = $aOpts['stateType'];
$scale = 100;
$showstate = 0;

/*******************************************************************************
 * Get gadget_opts
 * ****************************************************************************/

$opts = explode(",", $_GET["opts"]);

foreach ($opts as $current) {
	
	# Break options key=val pairs apart
	$keyval = explode("=",$current);

	# Assign key value pairs

	# Options for displaying perfdata
	if (preg_match('/pdi/i',$keyval[0])) {
		$value = $aPerfdata[$keyval[1]-1]['value'];
		$uom = $aPerfdata[$keyval[1]-1]['uom']; 
	}	
	if (preg_match('/uom/i',$keyval[0])) {
		$uom = $keyval[1]; 
	}
	if (preg_match('/scaleunits/i',$keyval[0])) {
		$scaleunits = $keyval[1]; 
	}

	# Options for displaying service states
        # Assign options to appropriate state
        if (preg_match('/ok|okay/i',$keyval[0])) {
                $stateArray["OK"] = $keyval[1];
		$showstate = 1;
        }
        if (preg_match('/warn|warning/i',$keyval[0])) {
                $stateArray["WARNING"] = $keyval[1];
		$showstate = 1;
        }
        if (preg_match('/crit|critical/i',$keyval[0])) {
                $stateArray["CRITICAL"] = $keyval[1];
		$showstate = 1;
        }
        if (preg_match('/unknown/i',$keyval[0])) {
                $stateArray["UNKNOWN"] = $keyval[1];
		$showstate = 1;
        }

	# Options for both service states and perfdata
	if (preg_match('/bgcolor/i',$keyval[0])) {
		$bgcolor = $keyval[1]; 
	}
	if (preg_match('/showstate/i',$keyval[0])) {
		if (preg_match('/y|yes|1/i',$keyval[1])) {
			$showstate = 1; 
		}
	}
	
	if (preg_match('/font/i',$keyval[0])) {
		$fontFile = './rawOut/' . $keyval[1];
		// If it does not exist - bail out!
		if ( ! file_exists($fontFile) ) {
		        errorBox("ERROR: FontFile $fontFile not found");
		}
	}
	
	if (preg_match('/percent/i',$keyval[0])) {
		if (preg_match('/y|yes|1/i',$keyval[1])) {
       $percent = 1;
		}
	}
	
}

/*******************************************************************************
 * Calculate Perfdata stuff
 ******************************************************************************/

if ($showstate == 0){
	// scale perfdata if requested (and necessary)
	if (preg_match('/y|yes|1/i',$scaleunits)) {
		// Rounding requested
		if (preg_match('/b|bytes|bits|kb|mb|gb|tb|pb/i',$uom)) {
			// Working with bytes or bits, use 1024 base
			$base = 1024;		
		} elseif (preg_match('/s|sec/i',$uom)){
			// Working seconds
			$base = 60;
		} else {
			$base = 1000;
		}
	
		// If working with time, obviously using different units, handle differently
		if ($base == 60) {
			$d = intval($value / 86400);
			$value = $value - ($d * 86400);
			$h = intval($value / 3600);
			$value = $value - ($h * 3600);
			$m = intval($value / 60);
			$value = $value - ($m * 60);
			$time = $d . "d:" . $h . "h:" . $m . "m:" . $value . ":s";
			$value = $time;
			$uom = "";
		} else {
			$i = 0;
			# Determine where we are starting
			if (preg_match('/kb/i',$uom)) {
				$i = 1;
				$uom = ltrim($uom,"kK");		
			}
			if (preg_match('/mb/i',$uom)) {
				$i = 2;		
				$uom = ltrim($uom,"mM");		
			}
			if (preg_match('/gb/i',$uom)) {
				$i = 3;		
				$uom = ltrim($uom,"gG");		
			}
			if (preg_match('/tb/i',$uom)) {
				$i = 4;		
				$uom = ltrim($uom,"tT");		
			}
			while ($value >= $base){
				$value = $value / $base;
				$i = $i + 1;
			}
			$value = round($value,2);
			switch ($i) {
				case 1:
					$uom = "K" . $uom;
					break;
				case 2: 
					$uom = "M" . $uom;
					break;
				case 3:
					$uom = "G" . $uom;
					break;
				case 4:
					$uom = "T" . $uom;
					break;
				case 5:
					$uom = "P" . $uom;
					break;
			}
		}
	} else if ( $percent == 1 ) {
   # if announcement in per cent desired�
   $value = number_format(round(($value-$min)*100/($max-$min),2),2);
   $uom="%";
  }
	# Assign output
	$label = $value . $uom;
}

/*******************************************************************************
 * Calculate TEXT stuff
 ******************************************************************************/
# Assign option label to output based on current state
if ($showstate == 1){
	$label = $stateArray["OK"];
	$state = $aOpts['state'];
	$stateType = $aOpts['stateType'];
	switch ($state) {
	
	        case "OK":
	                $label = $stateArray["OK"];
	                break;
	        case "WARNING":
	                $label = $stateArray["WARNING"];
	                break;
	        case "CRITICAL":
	                $label = $stateArray["CRITICAL"];
	                break;
	        case "UNKNOWN":
	                $label = $stateArray["UNKNOWN"];
	                break;
	        default:
	                $label = "unKNOWN";
	                break;
	}
}

/*******************************************************************************
 * Calculate needed stuff
 * ****************************************************************************/ 

// gadget scaling will be introduced with nagvis 1.4.3, therefore do some sanity checking to not break <=1.4.2
if ( isset($aOpts['scale']) ) {
	$scale = $aOpts['scale'];
} else {
	$scale = 100;
}

$fontSize = 70 * $scale / 100;

// Rotation 0 means no rotation at all
$fontRotation = 0;

// Calculate the size of the imagebox
$imagebox = imagettfbbox($fontSize, $fontRotation, $fontFile, $label);
$imgwidth = max(array($imagebox[0], $imagebox[2], $imagebox[4], $imagebox[6]))
  - min(array($imagebox[0], $imagebox[2], $imagebox[4], $imagebox[6])) + 3;
$imgheight = max(array($imagebox[1], $imagebox[3], $imagebox[5], $imagebox[7]))
  - min(array($imagebox[1], $imagebox[3], $imagebox[5], $imagebox[7])) + 3;

/*******************************************************************************
 * Create the actual image
 * ****************************************************************************/ 

// We add a few px to the calculated width/height because of our shadow
$img = @imagecreatetruecolor($imgwidth + 10, $imgheight + 2);

// Define the colors we want to use
if (isset($bgcolor)){
	$rgb = html2rgb($bgcolor);
	$oBackground = imagecolorallocate($img, $rgb[1], $rgb[2], $rgb[3]);
} else {
	$oBackground = imagecolorallocate($img, 255, 255, 255);
}

$oGreen = imagecolorallocate($img, 0, 255, 0);
$oYellow = imagecolorallocate($img, 255, 255, 0);
$oRed = imagecolorallocate($img, 255, 0, 0);
$oShadow = imagecolorallocate($img, 0x66, 0x66, 0x66);

// Colorize dependend on state - but only if the state is non-OK && HARD
if ( $aOpts['state'] != 'OK' && $aOpts['stateType'] == 'HARD' ) {
        if ( $aOpts['state'] == 'WARNING' ) {
                $oColor = $oYellow;
        } else {
                if ( $aOpts['state'] == 'CRITICAL' ) {
                        $oColor = $oRed;
                }
        }
} else {
        $oColor = $oGreen;
}


// Set background to transparent
imagefill($img, 0, 0, $oBackground);
imagecolortransparent($img, $oBackground);

// Now we create the shadow to make the visual experience deeper...
// No shadow for smaller scales, too hard to read
If ($scale >= 50) {
	ImageTTFText($img, $fontSize, $fontRotation, 2, $fontSize+2, $oShadow, $fontFile, $label);
} elseif ($scale >=15) {
	ImageTTFText($img, $fontSize, $fontRotation, 1, $fontSize+1, $oShadow, $fontFile, $label);
}	

// Write the perfdata value suceeded by the uom into the image
ImageTTFText($img, $fontSize, $fontRotation, 0, $fontSize, $oColor, $fontFile, $label);

// Output image.
if(function_exists('imageantialias')) {
        imageantialias($img, true);
}

header("Content-type: image/png");
imagepng($img);
imagedestroy($img);

function html2rgb($color)
{    
	if ($color[0] == '#')
	        $color = substr($color, 1);
	if (strlen($color) == 6)
		list($r, $g, $b) = array($color[0].$color[1],
					$color[2].$color[3],
					$color[4].$color[5]);
	elseif (strlen($color) == 3)
		list($r, $g, $b) = array($color[0].$color[0],
					$color[1].$color[1],
					$color[2].$color[2]);
	else        
		return false;
	$r = hexdec($r); $g = hexdec($g); $b = hexdec($b);
	return array($r, $g, $b);
}


?>
