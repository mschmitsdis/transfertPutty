<?php
/*****************************************************************************
 *
 * Version 0.9
 *
 * scale_thermometer.php - gadget for NagVis
 *
 * Heavily rewritten script taken from std_speedomerter.php provided by the 
 * NagVis team
 * 
 * Copyright (c) 2004-2008 NagVis Project (Contact: lars@vertical-visions.de)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************
 *
 * This is a simple gadget for NagVis. A gadget is a script which generates a
 * dynamic image for visualizing things as graphics in NagVis.
 *
 * The gadget gets its data from the NagVis frontend by parameters. This
 * gadget only needs the "perfdata" parameter. NagVis also passes the
 * following parameters to the gadgets:
 *  - name1:     Hostname
 *  - name2:     Service description
 *  - state:     Current state
 *  - stateType: Current state type (soft/hard)
 *
 *****************************************************************************/

/** 
 * Dummy perfdata for WUI
 *
 * This string needs to be set in every gadget to have some sample data in the 
 * WUI to be able to place the gadget easily on the map
 ******************************************************************************/
$sDummyPerfdata = 'config=20%;80;90;0;100';

// Load gadget core functions
require('./gadgets_core.php');

/*******************************************************************************
 * Start gadget main code
 ******************************************************************************/

header("Content-type: image/png");

//==========================================
// Set Minimum, Default, and Maximum values.
//==========================================

$min = 0;
$max = -1;
$default = 0; 
if ($warn == 0 AND $crit==0) {
	$warn = null;
	$crit = null;
}


//======================
// Calculate image size
//======================

$instance_font_size = 2;
$image_font_width = imagefontwidth($instance_font_size);
$image_font_height = imagefontheight($instance_font_size);
$instwidth = 90; # width of individual instance
$instheight = 125; # height of individual instance
$split_by_space = 1; # use 1 to split label at spaces, 0 to split by length of instance image
$pad = 20; # percent to pad top and bottom values of graph
$inst_base = 1024; # set base for base 10 or base 2

# Count number of instances
$inst_count = count($aPerfdata);

//=====================================
// Calculate space needed for 
//=====================================

# Measure longest label
$long_label = 0;
foreach ($aPerfdata as $inst){

	if ($split_by_space == 0){
		# split label by fixed length
		if ( $long_label <= strlen($inst['label']) ) {
			$long_label = strlen($inst['label']);
		}
	}
	else {
		# Calculate total rows by 'space split' label
		if ($long_label <= count(explode(" ",$inst['label'])) ){
			$long_label = count(explode(" ",$inst['label']));
		}
	}

}

if ($split_by_space == 0){
	# Split label by length
	$img_label_rows = round( ($long_label * imagefontwidth($instance_font_size) / ($instwidth - 10)) ); 
}
else {
	# Split by spaces ' ' in label string
	$img_label_rows = $long_label; 
}
$img_label_rows += 1;
$img_label_height = $img_label_rows * imagefontheight($instance_font_size);


//====================
// Create image.
//====================

$imgwidth = $instwidth * $inst_count + 25; # width of whole graphic
$imgheight = $instheight + $img_label_height + 10; # height of whole graphic
$rectwidth = 35; # width of individual bar
$rectheight = 120; # height of individual bar

$img = imagecreatetruecolor($imgwidth, $imgheight);

$oBackground = imagecolorallocate($img, 122, 23, 211);
$oBlack = imagecolorallocate($img, 0, 0, 0);
$oGreen = imagecolorallocate($img, 0, 255, 0);
$oYellow = imagecolorallocate($img, 255, 255, 0);
$oDarkYellow = imagecolorallocate($img, 240, 210, 100);
$oRed = imagecolorallocate($img, 255, 0, 0);
$oBlue = imagecolorallocate($img, 0, 0, 255);

imagefill($img, 0, 0, $oBackground);
imagecolortransparent($img, $oBackground);

//===========================================
// Loop Through instances of performance data
//===========================================

$loop = 0;
foreach ($aPerfdata as $instance){

	$value = floatval($instance['value']);
	$uom = $instance['uom'];
	$warn = floatval($instance['warning']);
	$crit = floatval($instance['critical']);
	$min = floatval($instance['min']);
	$max = floatval($instance['max']);
	// Clean up label text
	$instance_label = str_replace("\"","",$instance['label']);
	$instance_label = str_replace("\\\\",'\\',$instance_label);

$loop += 1;
$instance_len = strlen($instance_label);


//======================
// Determine base value
//======================

if ( is_null($inst_base) ) {
	# base number not hard coded, we'll try to determine it here
	
	#Bytes strings
	$bytes_string = "/(bytes|tb|gb|kb|mb|b)/i";
	if ( preg_match($bytes_string,$uom) ){
		# Units are in Bytes
		$inst_base = 1024;
	}
	else  {
		# Units are NOT in Bytes
		$inst_base = 1000;
	}
}


//============================
// Set scale (top and bottom) of bar graph
//============================

# Defaults
$bottom = 0;
$top = $value;

if ( is_null($min) OR is_null($max) OR $min == '' OR $max == ''  ){
	# ignore min and max values
	if ( (is_null($warn) OR is_null($crit)) OR ($warn == 0 OR $crit == 0 ) ){
		# ignore warn and crit values
		$oFill = $oGreen;
	}
	elseif ( $value < $warn AND $warn < $crit ) {
		$bottom = $value;
		$top = $crit;
		$oFill = $oGreen;
	}
	elseif ( $warn <= $value AND $value < $crit ){
		$bottom = $warn;
		$top = $crit;
		$oFill = $oYellow;
	
	}
	elseif ( $warn < $crit AND $crit <= $value ) {
		$bottom = $warn;
		$top = $value;
		$oFill = $oRed;
	}
	
	elseif ( $value <= $crit AND $crit < $warn ){
		$bottom = $value;
		$top = $warn;
		$oFill = $oGreen;
	}
	elseif ( $crit < $value AND $value <= $warn ){
		$bottom = $crit;
		$top = $warn;
		$oFill = $oYellow;
	}
	elseif ( $crit < $warn AND $warn < $value) {
		$bottom = $crit;
		$top = $value;
		$oFill = $oRed;
	}

	# Add padding % to top and bottom values
	$bottom_pad = ($bottom * $pad) / 100;
	$bottom = intval($bottom - $bottom_pad);
	$top_pad = ($top * $pad) / 100;
	$top = intval($top + $top_pad);
}
else{
	$bottom = $min;
	$top = $max;
}

# Reset top and bottom if UOM is percentage
if ( $uom == "%" AND ($min == '' OR $max == '') ){
	$bottom = 0;
	$top = 100;
	$inst_base = 1000;
}


//==============================
// Normalize / Fix value and max
//==============================

if ( is_null($value) ){
	$value = $default;
}
else {

	if ( function_exists('bcscale') ){
		# BC Math functions exists use them	
		// Call function to normalize value
		$value_arr = bcnorm($value, $inst_base);
		$crit_arr = bcnorm($crit, $inst_base);
		$warn_arr = bcnorm($warn, $inst_base);
		$top_arr = bcnorm($top, $inst_base);
		$bottom_arr = bcnorm($bottom, $inst_base);
	}
	else{
		# Normalize without bcmath functions
		$value_arr = norm($value, $inst_base);
		$crit_arr = norm($crit, $inst_base);
		$warn_arr = norm($warn, $inst_base);
		$top_arr = norm($top, $inst_base);
		$bottom_arr = norm($bottom, $inst_base);
	}
	
	$value = $value_arr[0];
	$value_pwr = $value_arr[1];
	$crit = $crit_arr[0];
	$crit_pwr = $crit_arr[1];
	$warn = $warn_arr[0];
	$warn_pwr = $warn_arr[1];
	$top = $top_arr[0];
	$top_pwr = $top_arr[1];
	$bottom = $bottom_arr[0];
	$bottom_pwr = $bottom_arr[1];
}
	

//==================
// Set image sizing.
//==================

$instx1 = ($loop - 1) * $instwidth;
$rectxoffset = 45; # Distance to start thermometer from left of image
$rectyoffset = 10; # Distance to start thermometer from top of image
$tic_font_size = 2;
$linewidth = 3;
$imgcenterx = $instx1 + $instwidth / 2;
$imgcentery = $imgheight / 2;
$rectx1 = $instx1 + $rectxoffset;
$recty1 = $rectyoffset;
$rectcenterx = $rectx1 + ($rectwidth / 2);
$rectcentery = 5 ; 
$rectx2 = $rectx1 + $rectwidth;
$recty2 = $recty1 + $rectheight;
$instancex = $rectcenterx - ($instance_len * imagefontwidth($instance_font_size) / 2);
$instancey = $imgheight - ( $img_label_rows * $image_font_height );
$labelstartx = $instancex + 25;


//===================
// Set meter scale
//==================

if ( ($top - $bottom != 100) AND ($value != 0) AND ($top !=0) ){
	# Convert value to percentage of graph
	$value_per = ($value / $top ) * 100;	
}
else {
	# Assign value to value percent variable
	$value_per = $value;
}

#if ($value_per != 0){
	# Convert percent value to pixel y value
	$valuep = ($value_per * ($recty2 - $recty1)) / 100;  
#}
#else{
#	$valuep = ( 0 * ($recty2 - $recty1)) / 100;
#}

if ($warn != 0 AND !is_null($warn) ){
	$warnp = ($warn * ($recty2 - $recty1)) / 100; # convert warning level to pixel y value
}
else {
	# Warning is of no value (null or zero)
	$warnp = $valuep + 100;
}

if ($crit != 0 AND !is_null($crit)){
	$critp = ($crit * ($recty2 - $recty1)) / 100; # convert critical level to pixel y value
}
else{
	# Crit of no value (null or zero)
	$critp = $valuep + 200;
}

// Debug lines
#imageline($img, 0, 0, $imgwidth, $imgheight, $oBlack);
#imageline($img, 0, $imgheight, $imgwidth, 0, $oBlack);
#imagestring($img, $instance_font_size, $imgcenterx, $imgcentery, $value_pwr, $oBlack);
#imagestring($img, $tic_font_size, $rectx1 - (imagefontwidth($tic_font_size) * (strlen($mid_label) + 2)), (($rectheight / 2) + $rectyoffset) - ((imagefontheight($tic_font_size)) - 20) / 2, $value_pwr, $oBlack); 

//========
// Draw bar graph frame
//========

imagerectangle($img,$rectx1, $recty1, $rectx2, $recty2, $oBlack);

//============
// Tic Marks
//============

$bottom = $bottom / 1;
$bottom_label = $bottom . $uom;
$mid_label = round($top / 2,1) . $uom;
$top = $top / 1;
$top_label = $top . $uom;

# bottom
imagestring($img, $tic_font_size, $rectx1 - (imagefontwidth($tic_font_size) * (strlen($bottom_label) + 2)), $recty2 - ((imagefontheight($tic_font_size))) / 2, $bottom_label, $oBlack); 
imageline($img, $rectx1 - 7, $recty2, $rectx1, $recty2, $oBlack);

# middle
imagestring($img, $tic_font_size, $rectx1 - (imagefontwidth($tic_font_size) * (strlen($mid_label) + 2)), (($rectheight / 2) + $rectyoffset) - ((imagefontheight($tic_font_size))) / 2, $mid_label, $oBlack); 
imageline($img, $rectx1 - 7, ($rectheight / 2) + $rectyoffset , $rectx1, ($rectheight / 2) + $rectyoffset , $oBlack);

# top
imagestring($img, $tic_font_size, $rectx1 - (imagefontwidth($tic_font_size) * (strlen($top_label) + 2)), $recty1 - ((imagefontheight($tic_font_size))) / 2, $top_label, $oBlack); 
imageline($img, $rectx1 - 7, $recty1, $rectx1, $recty1, $oBlack);

# Write scale on side of bar graph, if needed
$side_label = "X $inst_base^$value_pwr";
$side_label_len = strlen($side_label) * imagefontwidth($tic_font_size);
if ( $value_pwr > 0 ) {
	imagestringup($img, $tic_font_size, $rectx2 + imagefontwidth($tic_font_size) - 5 , ($rectheight) - $side_label_len / 2, $side_label, $oBlack); 
}


//================
// Instance Label
//================

if ($img_label_rows > 2 ){
	# Label longer than image, chop label into parts
	if ($split_by_space == 0){
		$newtext = str_split($instance_label,$instwidth - 75);
	}
	else {
		$newtext = explode(" ",$instance_label);
	}		
		$row_count = count($newtext);
		$newy = $recty2 + 5;
	for ($i = 1;$i <= $row_count; $i++){
		# Loop through rows of label	
		imagestring($img, $instance_font_size, $rectx1 - 20, $newy, $newtext[$i - 1], $oBlack);
		$newy = $newy + $image_font_height; 
	}
}
else 
{
	imagestring($img, $instance_font_size, $instancex, $instancey, $instance_label, $oBlack);
}


//====================================
// Fill rectangle with current value
//=====================================

if ($valuep != 0){ 
	imagefilledrectangle($img, $rectx1 + 2, $recty2 - $valuep, $rectx2 - 2, $recty2 - 1, $oFill);
}
else{
	# No value, dont fill bar graph
}

//==================================
// Print current value on bar chart
//==================================

	if ( $value_per > 10) {
		imagestring($img, $tic_font_size, $rectcenterx - (imagefontwidth($tic_font_size) * strlen(strval($value))) / 2, $recty2 - $valuep, $value, $oBlack);
	}
	else{
		imagestring($img, $tic_font_size, $rectcenterx - (imagefontwidth($tic_font_size) * strlen(strval($value))) / 2, $recty2 - ($valuep + 2 * imagefontwidth($tic_font_size)), $value, $oBlack);

	}


//=================
// Warning level
//================

if ($warn){
	imageline($img, $rectx1, $recty2 - $warnp, $rectx2 + 5, $recty2 - $warnp, $oDarkYellow);
	imagestring($img, $instance_font_size, $rectx2 + 8, ($recty2 - $warnp) - (imagefontheight($instance_font_size) / 2), "W", $oDarkYellow);
}

//===============
// Critical
//==============

if($crit){
	 imageline($img, $rectx1, $recty2 - $critp, $rectx2 + 5, $recty2 - $critp, $oRed); 
	imagestring($img, $instance_font_size, $rectx2 + 8, ($recty2 - $critp) - (imagefontheight($instance_font_size) / 2), "C", $oRed);
}


} # End instance Loop

//==============
// Output image.
//==============

if(function_exists('imageantialias')) {
	imageantialias($img, true);
}

imagepng($img);
imagedestroy($img);


//====================
// Functions
//===================

function bcnorm($target, $base){
	# Standarize the values and scale them
	$base = floatval($base);
	$power = 0;
	bcscale(3);
	if ( !is_float($target) ){
		# Convert numeric string to float value
		$target = floatval($target);
	}
	if ($target > 0 AND $target < 1){
		# Round small decimal values
		$target = bcdiv($target,'1');
		return array($target,$power);
	}
	elseif ($target >= $base){
		# Need to scale value down	
		$num_res = $target;
		while ( $num_res > $base ){
			$num_res = bcdiv($num_res,$base);
			$power += 1;
		}
		# Normalized value
		$target = floatval($num_res);
		$target = bcdiv($target,'1',1);
		return array($target, $power);
	}
	else {
		# We are less than the base number 
		$target = bcdiv($target,'1',1);
		return array($target, $power);
	}
}

function norm($target, $base){
	# We have a value to work with
	$power = 1;
	if ($target > 0 AND $target < 1){
		# Round small decimal values
		return array(round($target, $power),4);
	}
	elseif ($target >= $base){
		$num_res = gmp_div_qr($target,$base);
		while ( strlen(gmp_strval($num_res[0])) > 3 ){
			#Still to big 
			$num_res = gmp_div_qr($target, pow($base,$power));
			$power += 1;
		}
		# Normalized value
		return array(round(gmp_strval($num_res[0]) . "." . gmp_strval($num_res[1]),1), $power);
	#	return $target;
	}
	else {
		# We are less than the base number, do nothing
		return array($target, $power);
	}
}

?>
