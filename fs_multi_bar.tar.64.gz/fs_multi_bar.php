<?php
/*****************************************************************************
 *
 * name: fs_multi_bar.php
 *
 * This is a NagVis Gadget, it draws file system usage bars in the map.
 * The number of bars is determined by the number of objects in the perfdata.
 * Each Bar gets orange/red, when the state gets warning/critical
 * It displays the warning/critical ranges, the current usage in Percent
 *  and the Filesystemname (abbreviated).
 *
 * Following Parameters you can add in the Map-CFG:
 * scale=xxx	... Scale the Gadget (Value between 1 and 100)
 * xscale=xxx	... Scale the X-Axis of the Gadget (Value between 0 and 1)
 * yscale=xxx	... Scale the Y-Axis of the Gadget (Value between 0 and 1)

 * Author: Wolfgang Schulze-Zachau
 * Company: Amino Communications Ltd
 * Date: 03. Oct. 2011
 * Version: 1.0

 * This gadget is based on the original fs_usage_bar.php gadget by
 * Author: Richard Leitner, 
 * Company: Sony DADC Austria AG
 * Date: 20. Oct. 2010
 * Version 1.0
 *
 * The gadget gets its data from the NagVis frontend by parameters.
 *****************************************************************************/

/* Copyright (c) 2011 by Wolfgang Schulze-Zachau
 * License:
 * This program is free software;
 * you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published by the Free Software Foundation.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA
*/

$sDummyPerfdata="C:\ drive=0.37";
require('./gadgets_core.php');
//-----------------------------------------------------------------------------
// Configuration Variables
//-----------------------------------------------------------------------------
$width = 1000;
$height = 80;
$gap = 10;
$font='/usr/share/fonts/truetype/ttf-dejavu/DejaVuSans-Bold.ttf';

//-----------------------------------------------------------------------------
// Performance Variables
//-----------------------------------------------------------------------------
$value = 0.96;
$main_value=$value*100;
$filesystem='/dev/test';
$warning=0.9;
$critical=0.95;

//-----------------------------------------------------------------------------
// GET Variables
//-----------------------------------------------------------------------------
$scale = $_GET["scale"];
$xscale = $_GET["xscale"];
$yscale = $_GET["yscale"];

//-----------------------------------------------------------------------------
// get values from NagVis
//-----------------------------------------------------------------------------

$aOpts = Array('name1', 'name2', 'state', 'stateType', 'perfdata');
$aPerfdata = Array();

/**
 * Optional
 *  name1=localhost
 *  name2=Current Load
 *  state=OK
 *  stateType=HARD
 */

if(isset($_GET['perfdata']) && $_GET['perfdata'] != '') {
        $aOpts['perfdata'] = $_GET['perfdata'];
} elseif ($_GET['conf'] == "1"){
       $aOpts['perfdata'] = "/=4850MB;5848;6579;0;7311";
} else {
        errorBox('ERROR: The needed parameter "perfdata" is missing.');
}

//print_r($aOpts, true);

$aPerfdata = parsePerfdata($aOpts['perfdata']);

//-----------------------------------------------------------------------------
// Size calculation
//-----------------------------------------------------------------------------
if($scale != 0) {
       	$width = $width*$scale/100;
        $height = $height*$scale/100;
	$gap = $gap*$scale/100;
}
if($xscale != 0) {
       	$width = $width*$xscale;
}
if($yscale != 0) {
       	$height = $height*$yscale;
	$gap = $gap*$yscale;
}

$img_count = count($aPerfdata);
$im = ImageCreateTrueColor($width+1, ($height+1+$gap)*$img_count);
$y = 0;

//-----------------------------------------------------------------------------
// Color-Definition
//-----------------------------------------------------------------------------
$col_bg = ImageColorAllocate($im, 255, 255, 255);
$col_border = ImageColorAllocate($im, 0, 0, 0);
$col_critical = ImageColorAllocateAlpha($im, 255, 0, 0, 70);
$col_warning = ImageColorAllocateAlpha($im, 255, 215, 0, 70);
$col_inodes = ImageColorAllocateAlpha($im, 100, 100, 100, 0);
$col_text = ImageColorAllocate($im, 0, 0, 0);
$col_norm_val = ImageColorAllocateAlpha($im, 0, 189, 25, 30);
$col_warn_val = ImageColorAllocate($im, 255,215,0);
$col_crit_val = ImageColorAllocate($im, 255,0,0);

ImageFillToBorder($im, 0, 0, $col_bg, $col_bg);

foreach ($aPerfdata as $Perfdata) {
	$value=$Perfdata['value'];
	$warning=$Perfdata['warning'];
	$critical=$Perfdata['critical'];
	$max=$Perfdata['max'];
	$label = str_replace('\"','',$Perfdata['label']);
	// For Windows drives, often the label contains the drive UID, which really 
	// gets in the way in the display, so we trim it off.
	$colon_pos = strpos($label, ':');
	if ($colon_pos !== FALSE) {
		$label = str_replace('\\\\','\\', $label);
		$label = substr($label, 0, $colon_pos+1);
	}
	$state=$_GET['state'];
	if ($max != 0) {
		$value = $value / $max + 0.01;
		$warning = $warning / $max;
		$critical = $critical / $max;
	} else {
		$value = 0;
		$max = 1;
		$warning = 1;
		$critical = 1;
	}
	$col_value = $col_norm_val;
	if ($value > $warning) $col_value = $col_warn_val;
	if ($value > $critical) $col_value = $col_crit_val;
	$main_value = sprintf("%d", $value*100);

//-----------------------------------------------------------------------------
// draw Gadget
//-----------------------------------------------------------------------------
//draw Frame
	ImageRectangle($im, 0, $y, $width, $y+$height, $col_border);
	ImageRectangle($im, 1, $y+1, $width-1, $y+$height-1, $col_border);
	//draw Warning/Critical area
	ImageFilledRectangle($im, $width*$warning, $y+2, $width*$critical-1, $y+$height-2, $col_warning);
	ImageFilledRectangle($im, $width*$critical, $y+2, $width-2, $y+$height-2, $col_critical);

//draw usage value
	if ($width*$value > $width-2) {
		ImageFilledRectangle($im, 2, $y+2, $width-2, $y+$height-2, $col_value);
	} else {
		ImageFilledRectangle($im, 2, $y+2, $width*$value, $y+$height-2, $col_value);
	}

//draw text
	$text = "$label ($main_value%)";
	ImageTTFText($im, 2*$height/5, 0, $width/100, $y+(3.5*$height/5), $col_text, $font, $text);

	$y += $height+1+$gap;
}
//-----------------------------------------------------------------------------
// Output Image
//-----------------------------------------------------------------------------
if(function_exists('ImageAntialias')) {
       	ImageAntialias($im, true);
}

header("Content-type: image/png");
ImagePNG($im);
ImageDestroy($im);

?>

