<?php

/*****************************************************************************
 *
 * overall-status.php 
 *
 * Copyright (c) 2010 Rene Storm
 *
 * License: Actually this software is under GPL 2, but will follow NagViz
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************
 *
 * This is a small Widget/Gadget which will show you the Overall Status of
 * your host and service via Matthias Kettler Livestatus.
 * You will need a livestatus socket in order to use this plugin
 *
 * Please edit $livestatus_socket 
 *****************************************************************************/

/** 
 * Dummy perfdata for WUI
 *
 * This string needs to be set in every gadget to have some sample data in the 
 * WUI to be able to place the gadget easily on the map
 ******************************************************************************/
$sDummyPerfdata = 'config=20%;80;90;0;100';

$livestatus_socket='unix:///usr/local/nagios/var/rw/live';


//Dont show acknowledged services and hosts
//$show_what="";
$show_what="Stats: acknowledged = 0\nStatsAnd: 2\n";


// Load gadget core functions
require('./gadgets_core.php');

/*******************************************************************************
 * Start gadget main code
 ******************************************************************************/

header("Content-type: image/png");

$services_str="empty";
$hosts_str="empty";

$ratio = $aOpts['scale'] / 100;
if ($ratio == 0)
{
	$ratio=1;
}
//$ratio=1;



$fp=fsockopen($livestatus_socket);
if (!$fp) 
{
	$services_str="ERROR: $errno - $errstr\n";
} 
else 
{
	fwrite($fp, "GET services\nStats: state = 0\n" . $show_what . "Stats: state = 1\n" . $show_what . "Stats: state = 2\n" . $show_what . "Stats: state = 3\n" . $show_what . "\n");
	$services_str=fgets($fp,128);
	fclose($fp);
	
	$services_str=trim($services_str);
	$services_arr = explode(";", $services_str);
	$services_OK = $services_arr[0];
	$services_WARN = $services_arr[1];
	$services_CRIT = $services_arr[2];
	$services_UNKN = $services_arr[3];
}

$fp=fsockopen("unix:///var/nagios/var/rw/live");
if (!$fp) 
{
	$hosts_str="ERROR: $errno - $errstr\n";
} 
else 
{
	fwrite($fp, "GET hosts\nStats: state = 0\n" . $show_what . "Stats: state = 1\n" . $show_what . "Stats: state = 2\n" . $show_what . "\n");
	$hosts_str=fgets($fp,128);
	$hosts_arr = explode(";", $hosts_str);
	$hosts_UP = $hosts_arr[0];
	$hosts_DOWN = $hosts_arr[1];
	$hosts_UNRE = $hosts_arr[2];
	fclose($fp);
}
//==================
// Set image sizing.
//==================


$imgwidth  = 300 * $ratio;
$imgheight = 60 * $ratio;


$img = imagecreate($imgwidth,$imgheight);
//For changeing Font size we should create own Image and resize, copy it. Lets do it in Version 2.0
$font_size = 10;
$background_color = ImageColorAllocate ($img, 200, 200, 200);
$text_color = ImageColorAllocate ($img, 233, 14, 91);
$black = ImageColorAllocate ($img, 0, 0, 0);
$white = ImageColorAllocate ($img, 255,255,255);
$green = ImageColorAllocate ($img, 58,209,28);
$yellow = ImageColorAllocate ($img, 209,209,58);
$red = ImageColorAllocate ($img, 209,28,28);

// First the Color Backgrouds
//White headline
imagefilledrectangle ( $img ,5 , 5  , ($imgwidth-5) , ($imgheight-5)/2 , $white );
// Host ok
imagefilledrectangle ( $img ,5 , ($imgheight-5)/2  , ($imgwidth-5)*(1/6) , ($imgheight-5) , $green );
// Host Crit
//not red, if 0
if ($hosts_DOWN != "0") 
	imagefilledrectangle ( $img ,($imgwidth-5)*(1/6) , ($imgheight-5)/2  , ($imgwidth-5)*(2/6) , ($imgheight-5) , $red );


// SRV ok
imagefilledrectangle ( $img ,($imgwidth-5)*(3/6) , ($imgheight-5)/2  , ($imgwidth-5)*(4/6) , ($imgheight-5) , $green );
// SRV Warn 
if ($services_WARN != "0")
	imagefilledrectangle ( $img ,($imgwidth-5)*(4/6) , ($imgheight-5)/2  , ($imgwidth-5)*(5/6) , ($imgheight-5) , $yellow );
// SRV Crit 
if ($services_CRIT != "0")
	imagefilledrectangle ( $img ,($imgwidth-5)*(5/6) , ($imgheight-5)/2  , ($imgwidth-5)*(6/6) , ($imgheight-5) , $red );



// Main Rec
imagerectangle ( $img , 5 , 5 , $imgwidth-5 , $imgheight-5 , $black );

//Main Cross
imageline ( $img, 5 , ($imgheight-5)/2 , $imgwidth-5 , ($imgheight-5)/2 , $black );
imageline ( $img, ($imgwidth-5)/2 , 5 , ($imgwidth-5)/2 , ($imgheight-5) , $black );

// lines
imageline ( $img, ($imgwidth-5)*(1/6) , ($imgheight-5)/2 , ($imgwidth-5)*(1/6) , ($imgheight-5) , $black );
imageline ( $img, ($imgwidth-5)*(2/6) , ($imgheight-5)/2 , ($imgwidth-5)*(2/6) , ($imgheight-5) , $black );
imageline ( $img, ($imgwidth-5)*(4/6) , ($imgheight-5)/2 , ($imgwidth-5)*(4/6) , ($imgheight-5) , $black );
imageline ( $img, ($imgwidth-5)*(5/6) , ($imgheight-5)/2 , ($imgwidth-5)*(5/6) , ($imgheight-5) , $black );

$text_height=imagefontheight($font_size);

$string="Hosts";
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth-5)*(1/4))-($text_width/2), ($imgheight-5)*(1/4)-($text_height/2), $string, $black);

$string="Services";
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth-5)*(3/4))-($text_width/2), ($imgheight-5)*(1/4)-($text_height/2), $string, $black);

//HOST 
$string=$hosts_UP;
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth)*(1/12))-($text_width/2), ($imgheight-5)*(3/4)-($text_height/2), $string, $black);


$string=$hosts_DOWN;
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth)*(3/12))-($text_width/2), ($imgheight-5)*(3/4)-($text_height/2), $string, $black);


$string=$services_OK;
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth)*(7/12))-($text_width/2), ($imgheight-5)*(3/4)-($text_height/2), $string, $black);

$string=$services_WARN;
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth)*(9/12))-($text_width/2), ($imgheight-5)*(3/4)-($text_height/2), $string, $black);


$string=$services_CRIT;
$text_width = imagefontwidth($font_size)*strlen($string);
ImageString($img, $font_size, (($imgwidth)*(11/12))-($text_width/2), ($imgheight-5)*(3/4)-($text_height/2), $string, $black);



imagepng($img);
imagedestroy($img);
?>
