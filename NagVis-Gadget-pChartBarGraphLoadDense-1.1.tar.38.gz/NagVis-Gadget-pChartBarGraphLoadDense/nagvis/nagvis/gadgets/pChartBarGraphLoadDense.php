<?php
/*****************************************************************************
 *
 * pChartBarGraphLoad.php - Gadget for NagVis to diplay load as bar graph
 *
 * Copyright (c) 2004-2009 NagVis Project (Contact: lars@vertical-visions.de, michael_luebben@web.de)
 * Portions Copyright (c) 2009 Sascha Runschke (Sascha.Runschke@gfkl.com)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

/*****************************************************************************
 * Changes to the original pChartBarGraphLoad.php:
 *
 * - Made the gadget thinner - removing the legend, title and outer graphics
 *
 * - Changed the scaling of the chart from dynamic to START0, making the y-axis
 *   always start at 0. This gives a better overall overview of unnatural peaks
 *
 * - Removed unnecessary calculations and variables, reducing the lines of code significantly
 *
 * - Added dummy perfdata for correct display of the gadget in the NagVis WUI
 *
 * - Implemented handling of the new scale parameter coming with NagVis 1.4.3
 *
 *****************************************************************************/

// define Dummy Perfdata for display in the WUI

$sDummyPerfdata = "load1=0.160;8.000;10.000;0;%20load5=0.710;7.000;9.000;0;%20load15=0.990;6.000;8.000;0;";

// Load gadget core functions
require('./gadgets_core.php');

/*******************************************************************************
 * Start gadget main code
 ******************************************************************************/

header("Content-type: image/png");

// The default size of the graphimage is 160x160px
// It can be altered by the scale parameter of NagVis 1.4.3 or higher

$scale = 100;

// gadget scaling will be introduced with nagvis 1.4.3, therefor do some sanity checking to not break <=1.4.2
if ( isset($aOpts['scale']) ) {
        $scale = $aOpts['scale'];
} else {
        $scale = 100;
}


$sizeX = 160 * $scale / 100;
$sizeY = 160 * $scale / 100;

$crit = $aPerfdata[0]['critical'];

// Draw pie chart and create image ouput
// Standard inclusions
include("./pChart/pChart/pData.class");
include("./pChart/pChart/pChart.class");
  
 // Dataset definition 
$DataSet = new pData;
$DataSet->AddPoint(array($aPerfdata[0]['value']),"Serie1");
$DataSet->AddPoint(array($aPerfdata[1]['value']),"Serie2");
$DataSet->AddPoint(array($aPerfdata[2]['value']),"Serie3");
$DataSet->AddAllSeries();
$DataSet->SetSerieName("Load1","Serie1");
$DataSet->SetSerieName("Load5","Serie2");
$DataSet->SetSerieName("Load15","Serie3");

// Initialise the graph
$Graph = new pChart($sizeX,$sizeY);
$Graph->setFontProperties("./pChart/Fonts/tahoma.ttf",8);
$Graph->setGraphArea(30,5,$sizeX-10,$sizeY-5);
$Graph->drawGraphArea(255,255,255,TRUE);
$Graph->SetFixedScale(0,$crit * 1.5 );
$Graph->drawScale($DataSet->GetData(),$DataSet->GetDataDescription(),SCALE_START0,0,0,0,TRUE,0,2,TRUE);
$Graph->drawGrid(4,TRUE,100,100,100,40);

// Draw the bar graph
$Graph->drawBarGraph($DataSet->GetData(),$DataSet->GetDataDescription(),TRUE);

// Finish the graph
$Graph->setFontProperties("./pChart/Fonts/tahoma.ttf",9);
$Graph->Stroke();
?>
