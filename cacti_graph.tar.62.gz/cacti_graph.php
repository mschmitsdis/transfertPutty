<?php

/*************************************************************************
 *
 * cacti_graph.php
 *
 * Copyright (c) 2011 Wolfgang Schulze-Zachau (wszachau@aminocom.com)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************
 *
 * This is a simple gadget for NagVis. It retrieves a traffic chart from a cacti
 * installation and returns it to NagVis. 
 *
 * Since cacti graphs are generated on the fly, there is no point retrieving
 * an existing image. Rather, this gadget uses a cURL session to create the
 * required image. 
 * The gadget_opts value is used to identify the graph and various options.
 * For a description of these please read below.
/** 
 * Dummy perfdata for WUI
 *
 * This string needs to be set in every gadget to have some sample data in the 
 * WUI to be able to place the gadget easily on the map
 ******************************************************************************/
$sDummyPerfdata = 'config=20%;80;90;0;100';
$sBaseURL = 'http://netgraph/graph_image.php?';
$sCactiUser = 'guest';
$sCactiPass = 'p4ssw0rd';

// Load gadget core functions
require('./gadgets_core.php');

/*******************************************************************************
 * Start gadget main code
 ******************************************************************************/

/**
 * makeURL examines the string given as gadget options and builds
 * a valid cacti URL from it. The syntax for the string is as follows
 * 
 * opts=id:123,w:200,h:100,l:off,p:1d
 * 
 * where	id	the graph ID. shows in cacti URL's as local_graph_id
 * 		w	width in pixels
 * 		h	height in pixels (note: this does NOT include the legend)
 * 		l	whether to show the legend or not
 * 		p	period, optional. Possible values are
 * 			hh	last half hour
 * 			lh	last hour
 * 			2h	last 2 hours
 * 			4h	last 4 hours
 * 			6h	last 6 hours
 * 			12h	last 12 hours
 * 			1d	last 24 hours = last day
 * 			2d	last 48 hours = last 2 days
 * 			4d	last 4 days
 * 			1w	last week
 * 			2w	last 2 weeks
 * 			1m	last month
 * 			2m	last 2 months
 * 			4m	last 4 months
 * 			6m	last 6 months
 * 			1y	last year
 * 			2y	last 2 years
 * 
 * The default URL for the cacti site has to be defined in a global variable
 * The id value is mandatory, all others are optional. Defaults are
 * 		w	250
 * 		h	150
 * 		l	off
 * 		p	1d
 * 
 * Width and Height must be a positive number between 50 and 2000, otherwise the defaults kick in.
 * Possible values for the "l" option are on, off, true, false, 0, 1
 * Any other options will be discarded/ignored
 */

function makeURL($option) {
	global $sBaseURL;
	$opts = array(
		'id' => 0,
		'w'  => 250,
		'h'  => 150,
		'l'  => true,
		's'  => 0,
		'e'  => 0,
		'p'  => '1d'
	);
	$items = explode(',', $option);
	if (!is_array($items) || count($items) == 0) return '';
	foreach ($items as $item) {
		$bits = explode(':', $item);
		$opts[$bits[0]] = $bits[1];
	}
	if (validate_options($opts) == FALSE) return '';
	$url = $sBaseURL.'local_graph_id='.$opts['id'];
	$url .= '&rra_id=0';
	$url .= '&graph_height='.$opts['h'];
	$url .= '&graph_width='.$opts['w'];
	$url .= '&graph_nolegend='.$opts['l'];
	$url .= '&graph_start='.$opts['s'];
	$url .= '&graph_end='.$opts['e'];
	return $url;
}

/**
 * validate_options inspects all the given options and restricts them to 
 * useful ranges. It also interprets the period option and creates the 
 * necessary start and end time stamps.
 */

function validate_options(&$opts) {
	
	$legend = array('true','false','0','1','on','off','TRUE','FALSE','ON','OFF');
	$period = array('hh'=>1800,'1h'=>3600,'2h'=>7200,'4h'=>14400,'6h'=>21600,
			'12h'=>43200,'1d'=>86400,'2d'=>172800,'4d'=>345600,
			'1w'=>604800,'2w'=>1209600,'1m'=>259200,'2m'=>5184000,
			'4m'=>10368000,'6m'=>15724800,'1y'=>31536000,'2y'=>63072000);

	if ($opts['id'] <= 0 || $opts['id'] == '') return FALSE;
	if ($opts['w'] <= 50 || $opts['w'] > 2000) $opts['w'] = 250; 
	if ($opts['h'] <= 50 || $opts['h'] > 2000) $opts['h'] = 150; 
	if (!in_array($opts['l'], $legend)) $opts['l'] = 'true';
	if (!in_array($opts['p'], array_keys($period))) $opts['p'] = '1d';
	$opts['e'] = time();
	$opts['s'] = $opts['e'] - $period[$opts['p']];
	return TRUE;
}

header("Content-type: image/png");

$url = makeURL($aOpts['opts']);
if ($url =='') {
	errorBox('Cannot find a suitable graph for host '.$aOpts['name1'].' and service '.$aOpts['name2']);
} else {

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_USERPWD, $sCactiUser.':'.$sCactiPass); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: image/png'));
	curl_exec($ch);
	curl_close($ch);
}

?>
