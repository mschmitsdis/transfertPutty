<?php
/*****************************************************************************
 *
 * rawWords.php - Gadget for NagVis displaying the state of an object as raw words
 * 
 * Inspired by Sascha Runschke's rawNumbers, thanks Sascha!
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * RAWWORDS - Modified version of rawNumbers written by Sashca Runschke modified
 * by Greg Frater
 *
 * This gadget displays the raw text of the state of an object from nagios.
 * It's purpose was to help display various objects status on large displays.
 * You can also display different words for each state, passed to the gadget as
 * options.
 *
 * The displayed text is rendered as png image with ttf script, while
 * the color of the text reflects the state of the service:
 * Green for OK, yellow for WARNING, red for CRITICAL.
 * BUT: this gadget only honors HARD states and considers any SOFT state
 * as OK, no matter if it's WARNING or CRITICAL.
 *
 * To change the text of the gadget pass your text to the gadget from the 
 * gadget_opts field in the gadget config.  To display "yes" for okay and "no" 
 * for critical enter this 'ok=yes,critical=no' in the gadget_opts field of the 
 * gadget.  
 * 
 *****************************************************************************/


// Set dummy perfdata for displaying the gadget in nagvis WUI mode
$sDummyPerfdata = "Temperature=99,5C;99,6;99,9;15;100";
$label = $aOpts['state'];

// Set default state values
$stateArray = array("OK" => "OK", "WARNING" => "WARNING", "CRITICAL" => "CRITICAL", "UNKNOWN" => "UNKNOWN");

require('./gadgets_core.php');

$fontFile = './rawWords/luxirr.ttf';

/*******************************************************************************
 * Sanity checking - we need a ttf font and the freetype2 library installed!
 * ****************************************************************************/ 

// If it does not exist - bail out!
if ( ! file_exists($fontFile) ) {
        errorBox("ERROR: FontFile $fontFile not found");
}

if ( ! function_exists('imagettfbbox') ) {
        errorBox('The FreeType2 library is needed by this gadget!');
}

/*******************************************************************************
 * Calculate needed stuff
 * ****************************************************************************/ 

$opts = explode(",",$_GET["opts"]);

// Assign gadget options to statearray
foreach ($opts as $current) {

	# Break options key=val pairs apart
	$keyval = explode("=",$current);

	# Assign options to appropriate state
	if (preg_match('/ok|okay/i',$keyval[0])) {
		$stateArray["OK"] = $keyval[1];
	}
	if (preg_match('/warn|warning/i',$keyval[0])) {
		$stateArray["WARNING"] = $keyval[1];
	}
	if (preg_match('/crit|critical/i',$keyval[0])) {
		$stateArray["CRITICAL"] = $keyval[1];
	}
	if (preg_match('/unknown/i',$keyval[0])) {
		$stateArray["UNKNOWN"] = $keyval[1];
	}
}

$label = $stateArray["OK"];
$state = $aOpts['state'];
$stateType = $aOpts['stateType'];
$scale = 100;

# Assign option label to output based on current state
switch ($state) {

	case "OK":
		$label = $stateArray["OK"];
		break;
	case "WARNING":
		$label = $stateArray["WARNING"];
		break;
	case "CRITICAL":
		$label = $stateArray["CRITICAL"];
		break;
	case "UNKNOWN":
		$label = $stateArray["UNKNOWN"];
		break;
	default:
		$label = "unKNOWN";
		break;
}

// gadget scaling will be introduced with nagvis 1.4.3, therefore do some sanity checking to not break <=1.4.2
if ( isset($aOpts['scale']) ) {
	$scale = $aOpts['scale'];
} else {
	$scale = 100;
}

$fontSize = 70 * $scale / 100;

// Rotation 0 means no rotation at all
$fontRotation = 0;


// Calculate the size of the imagebox

$imagebox = imagettfbbox($fontSize, $fontRotation, $fontFile, $label);
$imgwidth = max(array($imagebox[0], $imagebox[2], $imagebox[4], $imagebox[6]))
  - min(array($imagebox[0], $imagebox[2], $imagebox[4], $imagebox[6]));
$imgheight = max(array($imagebox[1], $imagebox[3], $imagebox[5], $imagebox[7]))
  - min(array($imagebox[1], $imagebox[3], $imagebox[5], $imagebox[7]));

/*******************************************************************************
 * Create the actual image
 * ****************************************************************************/ 

// We add a few px to the calculated width/height because of our shadow
$img = @imagecreate($imgwidth + 10, $imgheight + 2);

// Define the colors we want to use
$oBackground = imagecolorallocate($img, 255, 255, 255);
$oGreen = imagecolorallocate($img, 0, 255, 0);
$oYellow = imagecolorallocate($img, 255, 255, 0);
$oRed = imagecolorallocate($img, 255, 0, 0);
$oShadow = imagecolorallocate($img, 0x66, 0x66, 0x66);

// White background made transparent
imagefill($img, 0, 0, $oBackground);
imagecolortransparent($img, $oBackground);

// Colorize dependend on state - but only if the state is non-OK && HARD
if ( $aOpts['state'] != 'OK' && $aOpts['stateType'] == 'HARD' ) {
        if ( $aOpts['state'] == 'WARNING' ) {
                $oColor = $oYellow;
        } else {
                if ( $aOpts['state'] == 'CRITICAL' ) {
                        $oColor = $oRed;
                }
        }
} else {
        $oColor = $oGreen;
}

// Now we create the shadow to make the visual experience deeper...
ImageTTFText($img, $fontSize, $fontRotation, 2, $fontSize+2, $oShadow, $fontFile, $label);

// Write the perfdata value suceeded by the uom into the image
ImageTTFText($img, $fontSize, $fontRotation, 0, $fontSize, $oColor, $fontFile, $label);

// Output image.
if(function_exists('imageantialias')) {
        imageantialias($img, true);
}

header("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>
